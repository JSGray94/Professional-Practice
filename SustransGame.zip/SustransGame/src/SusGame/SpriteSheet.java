package SusGame;

import java.awt.image.BufferedImage;

public class SpriteSheet {

	//Declare buffered image object
	private BufferedImage sheet;
	
	//Constructor takes in BufferedImage
	public SpriteSheet(BufferedImage sheet) {
		
		this.sheet = sheet;
	}
	
	//Crop out part of a sprite sheet and return it as a 
	//Buffered Image
	public BufferedImage crop(int x, int y, int width, int height) {
		
		return sheet.getSubimage(x, y, width, height);
	}
	
}
