package SusGame;

import java.awt.Canvas;
import java.awt.Dimension;

import javax.swing.JFrame;

//Class is responsible for the displaying of the game window
public class Display {

	private JFrame frame; // JFrame object
	private Canvas canvas; // Canvas object. Draw images to it.

	private String title; // Title of window
	private int width, height; // Width and height of window.

	// -----------------------------------------
	// -----------------------------------------

	// Basic constructor.
	public Display(String title, int width, int height) {

		this.title = title;
		this.width = width;
		this.height = height;

		createDisplay();
	}

	// Initialise JFrame
	private void createDisplay() {

		frame = new JFrame(title);
		frame.setSize(width, width);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Closes game on
																// closing
																// window.
		frame.setResizable(false); // Cant resize the window.
		frame.setLocationRelativeTo(null); // Window appears in centre of screen
		frame.setVisible(true);

		canvas = new Canvas(); // Create a new canvas object
		canvas.setPreferredSize(new Dimension(width, height)); // Set to width
																// and height of
																// game.
		canvas.setMaximumSize(new Dimension(width, height)); // Stays at width
																// an height
																// given.
		canvas.setMinimumSize(new Dimension(width, height));
		
		canvas.setFocusable(false); 	//Allows app to focus itself rather than panel.
		
		// Adds canvas to the frame.
		frame.add(canvas);
		frame.pack();// Resizes window a little to see all of the canvas.
	}

	// -------------------------------------------
	// -------------------------------------------

	public Canvas getCanvas() {

		return canvas;
	}
	
	//Returns JFrame
	public JFrame getFrame() {
		
		return frame;
	}
}
