package SusGame;

import java.awt.Graphics;

public class World {
	
	private int width, height;
	private int spawnX, spawnY;
	private int[][] tiles;
	private Handler handler;
	
	//Entities
	private EntityManager entityManager;
	
	//Default constructor
	public World(Handler handler, String path) {
		
		this.handler = handler;
		//Add in player.
		entityManager = new EntityManager(handler, new Player(handler, 100, 100));
		//Add in trees
		entityManager.addEntity(new Television(handler, 100, 250));

		//Loads in the tile set for the world
		loadWorld(path);
		
		entityManager.getPlayer().setX(spawnX);
		entityManager.getPlayer().setY(spawnY); 
	}
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	//Update variables.
	public void tick() {
		
		entityManager.tick();
	}
	
	//Update graphics
	public void render(Graphics g) {
		
		//Increase render efficiency. Only renders on screen tiles.
		//Returns whichever is bigger.
		int xStart = (int) Math.max(0, handler.getGameCamera().getxOffset() / Tile.TILE_WIDTH);	
		int xEnd = (int) Math.min(width, (handler.getGameCamera().getxOffset() + handler.getWidth()) / Tile.TILE_WIDTH + 1);
		int yStart = (int) Math.max(0, handler.getGameCamera().getyOffset() / Tile.TILE_HEIGHT);
		int yEnd = (int) Math.min(height, (handler.getGameCamera().getyOffset() + handler.getHeight()) / Tile.TILE_HEIGHT + 1);
		//End render efficiency.
		
		for (int y = yStart; y < yEnd; y++) {
			for(int x = xStart; x < xEnd; x++) {
				
				//Call get tile method to render tiles
				//Multiply by Tiles pixels to get actual world size.
				getTile(x, y).render(g,(int) (x * Tile.TILE_WIDTH - handler.getGameCamera().getxOffset()), 
						(int) (y * Tile.TILE_HEIGHT - handler.getGameCamera().getyOffset())); 
			}
		}
		//Rebder entity.
		entityManager.render(g); 
	}
	
	//Finds ID in tile array
	public Tile getTile(int x, int y) {
		
		//Do a check o see if player is out of bounds.
		if(x < 0 || y < 0 || x >= width || y >= height)
			return Tile.grassTile;
		
		Tile t = Tile.tiles[tiles[x][y]];
		
		//Only set so many tiles so this does a check on id.
		if(t == null)
			return Tile.grassTile;
		
		return t;
	}
	
	//Load in the world tiles.
	private void loadWorld(String path) {
		
		String file = Utils.loadFileAsString(path); 
		String[] tokens = file.split("\\s+");	//Splits all white space.
		width = Utils.parseInt(tokens[0]);	//Width of map in file
		height = Utils.parseInt(tokens[1]);	//Height of map in file.
		spawnX = Utils.parseInt(tokens[2]);	//SpawnX inside file
		spawnY = Utils.parseInt(tokens[3]);	//spawnY inside file
		
		tiles = new int[width][height];
		for(int y = 0; y < height; y++) {
			for(int x = 0; x < width; x++) {
				
				tiles[x][y] = Utils.parseInt(tokens[(x + y * width) + 4]);	//
			}
		}

	}
	
	//----------------------------------
	//----------------------------------
	
	public int getWidth() {
		
		return width;
	}
	public int getHeight() {
		
		return height;
	}

}
