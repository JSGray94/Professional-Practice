package SusGame;


public class Launcher {
	
	public static void main(String args[]) {

		//create new game object
		Game game = new Game("Sustrans Game", 800, 600);
		//Start the game
		game.start();
	}
	
}
