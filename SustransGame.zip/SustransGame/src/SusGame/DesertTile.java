package SusGame;

import java.awt.image.BufferedImage;

public class DesertTile extends Tile{

	public DesertTile(int id) {
		super(Assets.desert, id);
		
	}

}
