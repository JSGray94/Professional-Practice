package SusGame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Player extends Creature {

	//Animations
	private Animation animDown, animUp, animLeft, animRight;
	
	//Physical and mental health.
	private float mentalHealth;
	private float physicalHealth;
	
	// Default constructor
	public Player(Handler handler, float x, float y) {
		// Call creature constructor.
		super(handler, x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);

		//Set up player bounding box.
		bounds.x = 16;
		bounds.y = 32;
		bounds.width = 15;
		bounds.height = 32;
		
		//Setting Physical and mental health attributes.
		mentalHealth = 50;
		physicalHealth = 50;
		
		//Animation
		animDown = new Animation(300, Assets.player_down);
		animUp = new Animation(300, Assets.player_up);
		animLeft = new Animation(300, Assets.player_left);
		animRight = new Animation(300, Assets.player_right);
	}

	// Update variables.
	@Override
	public void tick() {

		//Tick animation
		animDown.tick();
		animUp.tick();
		animLeft.tick();
		animRight.tick();
		
		//Calls this method.
		getInput();
		
		//Got from creature class.
		move();
		
		//Center camera on player.
		handler.getGameCamera().centerOnEntity(this);
	}

	// Gets player input.
	private void getInput() {

		xMove = 0;
		yMove = 0;

		//Increment player movement by speed based on key pressed.
		if (handler.getKeyManager().up) {

			yMove = -speed;
		}
		if (handler.getKeyManager().down) {

			yMove = speed;
		}
		if (handler.getKeyManager().left) {

			xMove = -speed;
		}
		if (handler.getKeyManager().right) {

			xMove = speed;
		}
	}

	// Update screen.
	@Override
	public void render(Graphics g) {

		// Draw player.
		g.drawImage(getCurrentAnimationFrame(), (int) (x - handler.getGameCamera().getxOffset()), (int) (y - handler.getGameCamera().getyOffset()), width, height, null);
	
		//Display physical and mental health
		g.drawString("Physical Health: " + String.valueOf(physicalHealth), 10, 10);
		g.drawString("Mental Health: " + String.valueOf(mentalHealth), 10, 30);
		
		/*
		//Display players bounding box.
		g.setColor(Color.red);
		g.fillRect((int) (x + bounds.x - handler.getGameCamera().getxOffset()), 
				(int) (y + bounds.y - handler.getGameCamera().getyOffset()), 
				bounds.width, bounds.height);
		*/
	}
	
	private BufferedImage getCurrentAnimationFrame() {
		
		if(xMove < 0) {			//If moving left
			
			return animLeft.getCurrentFrame();
		}
		else if(xMove > 0) {	//Moving right
			
			return animRight.getCurrentFrame();
		}
		else if(yMove < 0) {	//Moving up
			
			return animUp.getCurrentFrame();
		}
		else {					//Moving down
			
			return animDown.getCurrentFrame();
		}
		
	}

}
