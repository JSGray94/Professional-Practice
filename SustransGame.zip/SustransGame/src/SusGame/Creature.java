package SusGame;

//Creature extends entity.
public abstract class Creature extends Entity {

	// Cannot change once set.
	// Initial creature health.
	public static int DEFAULT_HEALTH = 10;
	// Default speed cannot change
	public static final float DEFAULT_SPEED = 3.0f;
	// Default width and height variables.
	public static final int DEFAULT_CREATURE_WIDTH = 64, DEFAULT_CREATURE_HEIGHT = 64;

	// Give creature health variable.
	protected int health;
	// speed it moves
	protected float speed;
	//
	protected float xMove, yMove;

	// -----------------------
	// -----------------------

	public Creature(Handler handler, float x, float y, int width, int height) {
		super(handler, x, y, width, height); // Call entity class constructor

		health = DEFAULT_HEALTH;
		speed = DEFAULT_SPEED;
		xMove = 0;
		yMove = 0;

	}

	// ---------------------------
	// ---------------------------

	// Move methods.
	public void move() {

		if(!checkEntityCollisions(xMove, 0f))
		moveX();
		if(!checkEntityCollisions(0f, yMove))
		moveY();
	}

	//Moving and Collision
	public void moveX() {
		
		if(xMove > 0) {	//Moving right
			
			int tx = (int) (x + xMove + bounds.x + bounds.width) / Tile.TILE_WIDTH;	//Trying to move to
			//Collision detection for right side of the bounding box.
			if(!collisionWithTile(tx, (int) (y + bounds.y) / Tile.TILE_HEIGHT) &&
					!collisionWithTile(tx, (int) (y + bounds.y + bounds.height) / Tile.TILE_HEIGHT)) {
				
				x += xMove;
			}
			else {	//Was collision. Fix tile collision no gaps
				
				//Leave 1 pixel gap.
				x = tx * Tile.TILE_WIDTH - bounds.x - bounds.width -1;	//Set temp x to this.
			}
		}
		else if(xMove < 0) {	//Moving left
			//Collsion detection or left side of bounding box.
			int tx = (int) (x + xMove + bounds.x) / Tile.TILE_WIDTH;	//Trying to move to
			//Collision detection for right side of the bounding box.
			if(!collisionWithTile(tx, (int) (y + bounds.y) / Tile.TILE_HEIGHT) &&
					!collisionWithTile(tx, (int) (y + bounds.y + bounds.height) / Tile.TILE_HEIGHT)) {
				
				x += xMove;
			}
			else {
				
				x = tx * Tile.TILE_WIDTH + Tile.TILE_WIDTH - bounds.x;
			}
		}
	}
	//Moving and collision
	public void moveY() {

		if(yMove < 0) {	//Up
			
			int ty = (int) (y + yMove + bounds.y) / Tile.TILE_HEIGHT;
			//Collision detection with top of bounding box.
			if(!collisionWithTile((int) (x + bounds.x) / Tile.TILE_WIDTH, ty) && 
					!collisionWithTile((int) (x + bounds.x + bounds.width) / Tile.TILE_WIDTH, ty)) {
				y += yMove;
			}
			else {
				
				y = ty * Tile.TILE_HEIGHT + Tile.TILE_HEIGHT - bounds.y;
			}
		}
		else if(yMove > 0) {	//Down
			
			int ty = (int) (y + yMove + bounds.y + bounds.height) / Tile.TILE_HEIGHT;
			//Collision detection with top of bounding box.
			if(!collisionWithTile((int) (x + bounds.x) / Tile.TILE_WIDTH, ty) && 
					!collisionWithTile((int) (x + bounds.x) / Tile.TILE_WIDTH, ty)) {
			y += yMove;
			}	
			else {
				
				y = ty * Tile.TILE_HEIGHT - bounds.y - bounds.height - 1;
			}
		}
	}

	// If the tile is solid then return true, this tile cant be moved on.
	protected boolean collisionWithTile(int x, int y) {

		return handler.getWorld().getTile(x, y).isSolid();
	}

	// ---------------------------
	// ---------------------------

	public float getxMove() {
		return xMove;
	}

	public void setxMove(float xMove) {
		this.xMove = xMove;
	}

	public float getyMove() {
		return yMove;
	}

	public void setyMove(float yMove) {
		this.yMove = yMove;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public float getSpeed() {
		return speed;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}

}
